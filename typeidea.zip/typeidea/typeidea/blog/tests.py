# from django.test import TestCase
from django.contrib.admin import options

# Create your tests here.


print("{name}".format(name="123"))
